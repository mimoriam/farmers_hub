class AppStrings {
  static const String appTitle = "Farmer Hub";

  // Splash Screen & Onboard Screen
  static const String language = "language";
  static const String yourCropIcon = "Your Crop Icon";
  static const String yourCrop = "YOUR CROP";
  static const String buySell = "Buy & Sell Securely Online.";

  // Login Screen
  static const String loginToCrop = "Login to YOUR CROP";
  static const String emailAddress = "Email Address";
  static const String email = "email";
  static const String enterEmail = "Enter your Email";
  static const String password = "Password";
  static const String passwordCondition = "Password must not be less than 6 characters";
  static const String enterPassword = "Enter Your Password";
  static const String forgotPassword = "Forgot Password?";
  static const String login = "Login";
  static const String signup = "Signup";
  static const String continueWith = "or continue with";
  static const String noAccount = "Don't have an account?";
  static const String warning = "Warning!";
  static const String finishRegisteration = "Please finish your user registration!";
  static const String ok = "Okay";

  //Signup Screen
  static const String additionalInfo = "Additional Information";
  static const String enterDetails = "Please enter your contact details to continue";
  static const String enterName = "Enter Your Name";
  static const String username = "username";
  static const String enterUsername = "Enter Name";
  static const String enterUserMail = "Enter Your Email";
  static const String enterPhoneNumber = "Enter Phone Number";
  static const String enterpassword = "Enter Password";
  static const String confirmPassword = "Confirm Password";
  static const String wrongPassword = "Passwords do not match";
  static const String confirmYourPassword = "Confirm Your Password";
  static const String alreadyAccount = "Already have an account? ";

  // Home Screen
  static const String fetchingLocation = "Fetching location...";
  static const String unknown = "Unknown";
  static const String gotNoLocation = "Could not get location";
  static const String locationServiceDisable = "Location Services Disabled";
  static const String enableLocationService = "Please enable location services in settings.";
  static const String openSettings = "Open Settings";
  static const String cancel = "Cancel";
  static const String exitApp = "Are you sure you want to exit the app?";
  static const String confirmExit = "Confirm Exit";
  static const String no = "N/A";
  static const String exit = "Exit";
  static const String homeIcon = "Home Icon";
  static const String home = "Home";
  static const String chatIcon = "Chat Icon";
  static const String chat = "Chat";
  static const String favoritesIcon = "Favorites Icon";
  static const String favorites = "Favorites";
  static const String unavailable = "Unavailable";
  static const String profileIcon = "Profile Icon";
  static const String profile = "Profile";
  static const String location = "Location: ";
  static const String locationNew = "Location";
  static const String loading = "Loading...";
  static const String damascus = "Damascus";
  static const String aleppo = "Aleppo";
  static const String homs = "Homs";
  static const String hama = "Hama";
  static const String latakia = "Latakia";
  static const String tartus = "Tartus";
  static const String baniyas = "Baniyas";
  static const String idlib = "Idlib";
  static const String deirezzor = "Deir ez-Zor";
  static const String alhasakah = "Al-Hasakah";
  static const String qamishli = "Qamishli";
  static const String raqqa = "Raqqa";
  static const String daraa = "Daraa";
  static const String adsuwayda = "As-Suwayda";
  static const String quenitra = "Quneitra";
  static const String almayadin = "Al-Mayadin";
  static const String albakamal = "Al-Bukamal";
  static const String rifdimashq = "Rif Dimashq";
  static const String afrin = "Afrin";
  static const String manbij = "Manbij";
  static const String tellabyad = "Tell Abyad";
  static const String asalayn = "Ras al-Ayn";
  static const String kobani = "Kobani";
  static const String go = "Go";
  static const String noPost = "No featured posts to view.";
  static const String failedToLoad = "Failed to load user data.";
  static const String flameIcon = "Flame Icon";
  static const String popularPost = "Popular Posts";
  static const String viewAll = "View all";
  static const String categories = "Categories";
  static const String search = "Search";
  static const String justNow = "Just now";
  static const String plantIcon = "Plant Icon";
  static const String farmingTip = "Farming Tip of the Day";
  static const String farmingDyTip = "Perfect day for soil preparation and planting seedlings. Moisture levels are optimal.";
  static const String exploreProducts = "Explore our Products";
  static const String explore = "Explore";
  static const String usd = "usd";
  static const String euro = "euro";
  static const String lira = "lira";
  static const String syp = "(SYP)";

  // Create Post Screen
  static const String createPost = "Create Post";
  static const String addProducts = "Add pictures for your Product";
  static const String addImages = "Add Images";
  static const String addUpToFour = "Add up to 4 photos for more views!";
  static const String addPostTitle = "Add Post Title";
  static const String typeHere = "Type here";
  static const String postTitleRequired = "Post title is required.";
  static const String city = "City";
  static const String selectCity = "Select Your City";
  static const String cityRequired = "City is required.";
  static const String village = "Village";
  static const String enterVillage = "Enter Village";
  static const String villageRequired = "Village is required.";
  static const String category = "Category";
  static const String selectCategory = "Select a category";
  static const String fruits = "Fruits";
  static const String vegetables = "Vegetables";
  static const String oliveOil = "Olive Oil";
  static const String liveStock = "Live Stock";
  static const String grainSeeds = "Grains & Seeds";
  static const String fertilizers = "Fertilizers";
  static const String tools = "Tools";
  static const String landServices = "Land Services";
  static const String equipments = "Equipments";
  static const String delivery = "Delivery";
  static const String workerServices = "Worker Services";
  static const String pesticides = "Pesticides";
  static const String animalsFeed = "Animal Feed";
  static const String others = "Others";
  static const String gender = "Gender";
  static const String male = "Male";
  static const String genderRequires = "Gender is required.";
  static const String female = "Female";
  static const String selectGender = "Select a Gender";
  static const String categoryRequires = "Category is required.";
  static const String averageWeight = "Average Weight (in kgs)";
  static const String enterAverageWeight = "Enter Average Weight in kilograms";
  static const String enterAverageWeightRequires = "Average weight is required.";
  static const String numberMust = "Must be a number.";
  static const String weighNotNegative = "Weight cannot be negative.";
  static const String weighNotExceed = "Weight cannot exceed.";
  static const String age = "Age (in years)";
  static const String enterAge = "Enter age in years";
  static const String ageRequires = "Age is required.";
  static const String ageNotNegative = "Age cannot be negative.";
  static const String ageNotExceed = "Age cannot exceed.";
  static const String quantity = "Quantity";
  static const String enterQuantity = "Enter Quantity";
  static const String quantityRequired = "Quantity is required.";
  static const String mustWholeNumber = "Must be a whole number.";
  static const String quantityLeastOne = "Quantity must be at least 1.";
  static const String currency = "Currency";
  static const String syria = "Syria";
  static const String Usd = "Usd";
  static const String Euro = "Euro";
  static const String Lira = "Lira";
  static const String price = "Price";
  static const String enterPrice = "Enter Your Price";
  static const String priceRequires = "Price is required.";
  static const String priceNotNegative = "Price cannot be negative.";
  static const String additionalDetails = "Additional Details";
  static const String uploadImage = "Upload an image!";
  static const String uploadFourImagesOnly = "Can't upload more than 4 images!";
  static const String submit = "Submit";

  // Categories Screen
  static const String apple = "Apples";
  static const String cheese = "Cheese";
  static const String pomegranates = "Pomegranates";
  static const String searchCategories = "Search Categories";
  static const String popularCategories = "Popular Categories";
  static const String userName = "User Name";
  static const String lastMessage = "Last message...";
  static const String usernameSpace = "User Name...........";
  static const String somethingWrong = "Something went wrong:";
  static const String itsAvalabe = "Hi its available";
  static const String noMessage = "No messages yet";
  static const String contactSupport = "Contact Support";
  static const String contact = "Contact";
  static const String contactAdmin = "Would you like to contact an admin?";
  static const String allChats = "All Chats";
  static const String initialName = "initialName";
  static const String time = "Time";
  static const String typeMessage = "Type your message...";

  // Currency Exchange Screen
  static const String defaultCurrency = "defaultCurrency";
  static const String currencyExchange = "Currency Exchange";
  static const String usDollar = "US Dollar";


  // Details Screen
  static const String notLaunchDialer = "Could not launch the dialer for";
  static const String details = "Details";
  static const String postNotFound = "Post not found or has been deleted";
  static const String likes = "Likes:";
  static const String views = "Views:";
  static const String managePost = "Manage Posts";
  static const String post = "Posts";
  static const String noUserPost = "User has no posts!";
  static const String cantChat = "Can't chat with yourself";
  static const String whatsapp = "WhatsApp";
  static const String whatsappNotInstalled = "Whatsapp not installed";
  static const String verifiedSeller = "Verified Seller";
  static const String model = "Model:";

  // Edit Post Screen
  static const String editPost = "Edit Post";
  static const String subtitle = "Subtitle here";
  static const String postTitle = "Edit Post Title";
  static const String postTitleRequires = "Post title is required.";
  static const String selectYourCity = "Select Your City";

  //Edit Profile Screen
  static const String editProfile = "Edit Profile";
  static const String changePhoto = "Change Photo";
  static const String changeAddress = "Change Your Address";
  static const String enterAddress = "Enter Address";
  static const String saveChanges = "Save Changes";
  static const String changesSuccess = "Changes saved successfully!";
  static const String addressRequires = "Address is required.";
  static const String phoneNumberRequires = "Phone number is required.";
  static const String nameRequires = "Name is required.";
  static const String validPhoneNumber = "Please enter a valid number.";
  static const String nameMustHaveThreeLetters = "Name must be at least 3 characters.";
  static const String changeDisplayName = "Change Display Name";
  static const String error = "Error:";
  static const String errorsCorrection = "Please correct the errors in the form.";
  static const String invalidData = "Form data is invalid.";

  // Favourite Screen
  static const String myFavorites = "My Favorites";
  static const String postDetails = "Post details...";
  static const String haveNoFavorites = "You have no favorite posts yet!";
  static const String favoritesLoadingError = "Error loading favorites.";
  static const String myFavoritesPostTitle = "Favorite Post Title";

  // Send Feedback Screen
  static const String suggestions = "Do you have a suggestion or found a bug? Let us know in the field below.";
  static const String sendFeedback = "Send Feedback";
  static const String maxChars = "Max 120 Characters";
  static const String bug = "Bug";
  static const String submitFeedback = "Send Feedback";
  static const String suggestion = "Suggestion";
  static const String feedbackRequires = "Feedback is required.";
  static const String describeExperience = "Describe your experience here... ";
  static const String yourExperience = "How was your experience?";
  static const String sendYourFeedback = "Send Us Your Feedback!";

  // Filter Results Screen
  static const String speechRecognition = "Initializing speech recognition...";
  static const String listening = "Listening...";
  static const String retry = "Retry";
  static const String title = "Title";
  static const String noResults = "No results";
  static const String results = "Results";
  static const String searchResults = "Search Results";
  static const String descending = "Descending";
  static const String ascending = "Ascending";
  static const String filters = "Filters (1)";
  static const String filteredSearchResults = "Filtered Search Result";
  static const String searchBy = "Search by:";
  static const String startingListen = "Starting to listen...";
  static const String selectLanguage = "Select Language";
  static const String tryInitializing = "Would you like to try reinitializing?";
  static const String inputSelected = "• No default voice input app selected";
  static const String speechServiceDisabled = "• Speech services are disabled";
  static const String googleAppNotInstalled = "• Google app is not installed or updated";
  static const String failedRecognition = "Failed to initialize speech recognition";
  static const String speechUnavailable = "Speech recognition unavailable";
  static const String speechRecognitionIssue = "Speech Recognition Issue";
  static const String microphonePermissionNotGranted = "• Microphone permissions not granted";
  static const String speechNotWorking = "Speech recognition is not working. This might be because:";
  static const String pressMicrophone = "Ready! Press the microphone to start speaking...";
  static const String speechError = "Speech recognition not available. Please install Google app or enable speech services in your device Settings > Apps > Default apps > Voice input.";

  // Onboarding Screen
  static const String english = "English";
  static const String agreeTerms = "Agree Terms & Conditions";
  static const String terms = "Terms of Use Policy.";
  static const String continueAgree = "By continuing, you agree to ";
  static const String arabic = "Arabic";
  static const String chooseLanguage = " Choose Preferred Language'";
  static const String welcome = "Welcome to Farmers Hub! Buy & Sell Fruits, Vegetables, Livestock, & More – All Securely Online.";

  // Manage Post Screen
  static const String managePosts = "Manage Posts";
  static const String allPost = "All Posts";
  static const String sold = "Sold";
  static const String youSure = "Are you Sure?";
  static const String delete = "Delete";
  static const String sureForDeletePost = "Are you sure you want to delete this post? Once deleted, the data will be permanently removed.";
  static const String yourPostDetails = "Post details...";
  static const String youPostTitle = "Your Post Title";

  // Profile Screen
  static const String light = "Light";
  static const String name = "Name";
  static const String dark = "Dark";
  static const String themeMode = "Theme Mode";
  static const String postHistory = "Post History";
  static const String accountVerification = "Account Verification";
  static const String phoneNumber = "Phone Number";
  static const String noLaunch = "Could not launch";
  static const String customerSupport = "Customer support";
  static const String shareApp = "Share App";
  static const String profileInfo = "Profile Information";
  static const String deleteAccount = "Delete Account";
  static const String logout = "Logout of account";
  static const String privacyPolicy = "Privacy Policy";
  static const String userProfile = "User Profile";
  static const String profileSettings = "Profile Settings";



}
